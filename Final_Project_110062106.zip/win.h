#ifndef SCENE_WIN_H
#define SCENE_WIN_H
#include "game.h"
Scene scene_win_create(void);
#endif
#pragma once
