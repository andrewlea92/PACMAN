#ifndef SCENE_MENU_H
#define SCENE_MENU_H
#include "game.h"
Scene scene_menu_create(void);
#endif
